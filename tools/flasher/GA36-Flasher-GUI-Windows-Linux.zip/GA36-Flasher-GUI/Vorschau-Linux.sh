#!/bin/sh
cd -- "$(dirname -- "$0")" || exit 1
exec ./GA36-Flasher-Linux --gui-demo
