@echo off
start "GA36 Demo" "%~dp0GA36-Flasher-Windows.exe" --gui-demo
